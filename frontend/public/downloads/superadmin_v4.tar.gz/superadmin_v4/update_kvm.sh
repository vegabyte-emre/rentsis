#!/bin/bash
echo "=== SuperAdmin v4 - Ticket System ==="

BACKEND=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*backend" | head -1)
FRONTEND=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*frontend" | head -1)

echo "Backend: $BACKEND"
echo "Frontend: $FRONTEND"

[ -z "$BACKEND" ] || [ -z "$FRONTEND" ] && echo "ERROR!" && exit 1

echo "Updating..."
docker cp backend/server.py $BACKEND:/app/
docker cp backend/services $BACKEND:/app/
docker cp frontend/. $FRONTEND:/usr/share/nginx/html/

echo "Restarting..."
docker restart $BACKEND && sleep 3 && docker restart $FRONTEND

echo "=== Done! ==="
