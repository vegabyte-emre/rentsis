#!/bin/bash
echo "=== SuperAdmin Update - Landing Page ==="

BACKEND_CONTAINER=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*backend|backend.*superadmin" | head -1)
FRONTEND_CONTAINER=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*frontend|frontend.*superadmin" | head -1)

echo "Backend: $BACKEND_CONTAINER"
echo "Frontend: $FRONTEND_CONTAINER"

if [ -z "$BACKEND_CONTAINER" ] || [ -z "$FRONTEND_CONTAINER" ]; then
    echo "ERROR: Containers not found!"
    exit 1
fi

# Update backend
echo "Updating backend..."
docker cp backend/server.py $BACKEND_CONTAINER:/app/
docker cp backend/services $BACKEND_CONTAINER:/app/

# Update frontend
echo "Updating frontend..."
docker cp frontend/. $FRONTEND_CONTAINER:/usr/share/nginx/html/

# Restart
echo "Restarting..."
docker restart $BACKEND_CONTAINER
sleep 3
docker restart $FRONTEND_CONTAINER

echo ""
echo "=== Update Complete ==="
echo "Landing Page: http://72.61.158.147:9000"
echo "SuperAdmin: http://72.61.158.147:9000/superadmin/login"
