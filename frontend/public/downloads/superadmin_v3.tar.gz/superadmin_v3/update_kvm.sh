#!/bin/bash
echo "=== SuperAdmin v3 - Landing + Abonelik ==="

BACKEND=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*backend" | head -1)
FRONTEND=$(docker ps --format '{{.Names}}' | grep -E "superadmin.*frontend" | head -1)

echo "Backend: $BACKEND"
echo "Frontend: $FRONTEND"

[ -z "$BACKEND" ] || [ -z "$FRONTEND" ] && echo "ERROR: Containers not found!" && exit 1

echo "Updating backend..."
docker cp backend/server.py $BACKEND:/app/
docker cp backend/services $BACKEND:/app/

echo "Updating frontend..."
docker cp frontend/. $FRONTEND:/usr/share/nginx/html/

echo "Restarting..."
docker restart $BACKEND && sleep 3 && docker restart $FRONTEND

echo ""
echo "=== Done! ==="
echo "Landing: http://72.61.158.147:9000"
echo "SuperAdmin: http://72.61.158.147:9000/superadmin"
